#I have created this file
#View returns http response; so you have to import from Django HttpRespone

from django.http import HttpResponse
#Views and URLS

""" def index(request):
    return HttpResponse('''Hello World! Hii '''); """
""" def link1(request):
    return HttpResponse('''<a href="https://www.youtube.com/playlist?list=PLu0W_9lII9ah7DDtYtflgwMwpT3xmjXY9"> CodeWithHarry </a>''')

def pulse(request):
    return HttpResponse('''<a href="https://pulse.itvedant.com/index.php/site/login"> ITVedant Pulse </a> ''')

def about(request):
    return HttpResponse("About You") """

#Without using Templates Pipelining
""" def index(request):
    return HttpResponse('''Home 
                        <br><button> <a href="/index1">Display </a> </button>
                        <button> <a href="/removepunc">RemPunc </a> </button>
                        <button> <a href="/capitalizeFirst">Cap </a> </button> 
                        <button> <a href="/newLineRemove">newLineRem </a> </button>
                     <button><a href="/spaceRemove">SpaceRem </a> </button>
                        <button> <a href="/charCount">CharCount </a> </button>''') """
    

#Using templates
from django.shortcuts import render

def index(request):
    return render(request, "index1.html")

def analyze(request):
    #Get text here
    djtext = request.POST.get('text','default')
    
    #Get the checkbox value
    djremovepunc = request.POST.get('removepunc','off')
    djcap = request.POST.get('capitalize','off')
    djupper = request.POST.get('uppercase','off')
    djnewlineremove = request.POST.get('newLineRemove','off')
    djspaceremove = request.POST.get('spaceRemover','off')
    
    print(djtext);
    print(djremovepunc);
    print(djcap);
    #analyzed = djtext;

    #Check which checkbox is on
    
    if (djremovepunc == 'on'):
            punctuations='''!@##$%^&*(){}[].,:;_-~?|+-`\/<>"'''
            analyzed=" "
            for char in djtext:
                if char not in punctuations:
                    analyzed = analyzed + char;
            params = {'purpose':'remove puctuations','analyzed_text': analyzed }
            djtext = analyzed;
            #return render(request, 'analyze.html', params) 
        
    if(djcap == 'on'):
            analyzed= djtext.capitalize()
            print(analyzed)
            params = {'purpose':'Capitalize','analyzed_text': analyzed }
            djtext = analyzed;
            #return render(request, 'analyze.html', params) 
        
    if(djupper == 'on'):
            analyzed=" "
            for char in djtext:
                analyzed = analyzed + char.upper()
            params = {'purpose':'UPPERCASE','analyzed_text': analyzed }
            djtext = analyzed;
            #return render(request, 'analyze.html', params) 
        
    if(djnewlineremove == 'on'):
            analyzed=" "
            for char in djtext:
                if char != "\n" and char!='\r':
                    analyzed = analyzed + char.upper()
            params = {'purpose':'Removed new Lines','analyzed_text': analyzed }
            djtext = analyzed;
            #return render(request, 'analyze.html', params) 
        
    if(djspaceremove == 'on'):
            analyzed=" "
            for index,char in enumerate(djtext):
                if djtext[index] == " " and djtext[index+1]== " ":
                    pass
                else:
                    analyzed = analyzed + char.upper()
            params = {'purpose':'Removed  Extra Spaces','analyzed_text': analyzed }
            
    if(djremovepunc != 'on' and djnewlineremove != 'on' and djspaceremove != 'on' and djupper != 'on' and djcap != 'on'):
          return HttpResponse("Please select a valid option and try again");
    else:       #return render(request, 'analyze.html', params) 
        return render(request, 'analyze.html', params)   
        
    """  else:
            return HttpResponse("Error"); """
        
   # return HttpResponse('''Remove Punctuation <br> <a href="/">Back </a>''')

""" def index1(request):
   params = {'name':'Jessica','place':'Mumbai'}
   return render(request, 'index.html', params) """


""" def removepunc(request):
    #Get text here
    djtext = request.GET.get('text','default')
    print(djtext);
    return HttpResponse('''Remove Punctuation <br> <a href="/">Back </a>''')

def capFirst(request):
    return HttpResponse('''Capitalize First <br> <a href="/">Back </a> ''')

def newLineRemove(request):
    return HttpResponse('''Remove newLine <br> <a href="/">Back </a>''')

def spaceRemove(request):
    return HttpResponse('''Remove space <br> <a href="/">Back </a>''')

def charCount(request):
    return HttpResponse('''Character Count <br> <a href="/">Back </a>''') """